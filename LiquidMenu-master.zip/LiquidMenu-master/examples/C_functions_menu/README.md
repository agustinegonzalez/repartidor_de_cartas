Example 3: functions_menu
==================

![schematic](https://github.com/VasilKalchev/LiquidMenu/blob/master/examples/C_functions_menu/functions_menu.png?raw=true)
This example demonstrates how to attach functions to the "lines" in the menu.
