Example 1: hello_menu
==================

![schematic](https://github.com/VasilKalchev/LiquidMenu/blob/master/examples/A_hello_menu/hello_menu.png?raw=true)
This is the get started example demonstrating how to create
a menu of two screens with dynamically changing information.
