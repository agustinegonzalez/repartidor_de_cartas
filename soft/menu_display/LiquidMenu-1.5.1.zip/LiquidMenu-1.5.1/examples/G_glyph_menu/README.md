Example 7: glyph_menu
==================

![schematic](https://github.com/VasilKalchev/LiquidMenu/blob/master/examples/G_glyph_menu/glyph_menu.png?raw=true)
This example demonstrates how to create a custom character (glyph) and put it inside a LiquidLine object.
