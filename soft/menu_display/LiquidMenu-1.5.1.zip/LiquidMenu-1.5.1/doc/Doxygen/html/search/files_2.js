var searchData=
[
  ['recognizetype_2ecpp',['recognizeType.cpp',['../recognize_type_8cpp.html',1,'']]]
];
