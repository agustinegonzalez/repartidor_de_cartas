var searchData=
[
  ['start',['START',['../messages_8h.html#aee14722dd5e918c757b31070a3fcd22b',1,'messages.h']]],
  ['stop',['STOP',['../messages_8h.html#ae20b3ad59ad4ebcd680252aafbbd8bdd',1,'messages.h']]]
];
