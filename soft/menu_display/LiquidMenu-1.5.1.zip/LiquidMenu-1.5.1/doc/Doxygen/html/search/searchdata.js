var indexSectionsWithContent =
{
  0: "acdghilmnoprstu",
  1: "l",
  2: "glr",
  3: "acghilnoprsu",
  4: "cdlmr",
  5: "dp",
  6: "dl",
  7: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Macros",
  7: "Pages"
};

