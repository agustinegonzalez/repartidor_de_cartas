var searchData=
[
  ['rightfocus_138',['rightFocus',['../glyphs_8h.html#a098afc4dbc1308c201b8958dd471edc3',1,'glyph']]]
];
