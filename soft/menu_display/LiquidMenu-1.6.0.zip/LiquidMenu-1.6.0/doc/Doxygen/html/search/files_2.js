var searchData=
[
  ['recognizetype_2ecpp_93',['recognizeType.cpp',['../recognize_type_8cpp.html',1,'']]]
];
