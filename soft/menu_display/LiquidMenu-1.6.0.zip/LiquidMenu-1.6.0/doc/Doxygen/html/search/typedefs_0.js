var searchData=
[
  ['boolfnptr_139',['boolFnPtr',['../_liquid_menu_8h.html#ae137b45e90dec8b22fd4360f11d07a4c',1,'LiquidMenu.h']]]
];
