var searchData=
[
  ['next_5fscreen_56',['next_screen',['../class_liquid_menu.html#a6046bb5792ad188b25a5b0e2d7e27fc0',1,'LiquidMenu::next_screen()'],['../class_liquid_system.html#ae48a34e80b56c097a16d90741ede20bd',1,'LiquidSystem::next_screen()']]]
];
