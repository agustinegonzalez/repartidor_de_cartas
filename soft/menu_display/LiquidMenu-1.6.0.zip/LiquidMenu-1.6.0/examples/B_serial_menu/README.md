Example 2: serial_menu
==================

![schematic](https://github.com/VasilKalchev/LiquidMenu/blob/master/examples/B_serial_menu/serial_menu.png?raw=true)
This example uses the serial communication to execute commands.
