var searchData=
[
  ['customfocus',['customFocus',['../glyphs_8h.html#a5e05ec5a67cf3c9a6c0b7268d99d8988',1,'glyph']]]
];
