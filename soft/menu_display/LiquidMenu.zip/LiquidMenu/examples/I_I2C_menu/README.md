Example 9: I2C_menu
==================

![schematic](https://github.com/VasilKalchev/LiquidMenu/blob/master/examples/I_I2C_menu/I2C_menu.png?raw=true)
This is the "hello_menu" example configured for I2C connection.

**To use an I2C connection you need to define I2C as "true" in the "LiquidMenu_config.h" file.**

Tested with [LiquidCrystal_I2C][lc_i2c].

[lc_i2c]: https://github.com/marcoschwartz/LiquidCrystal_I2C
