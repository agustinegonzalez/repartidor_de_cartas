![example](https://raw.githubusercontent.com/VasilKalchev/LiquidMenu/master/doc/Images/example.gif)
